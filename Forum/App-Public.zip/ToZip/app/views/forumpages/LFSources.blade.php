@extends('layouts.base')

@section('content')
	<div class="container-fluid">
		<h4>Now I am on the Sources Page</h4>
		<p></p>
		<h5>Html, CSS</h5>
		<p> All of the code used in this website is my own, and design elements from Twitter Bootstrap </p>
		<h5>PHP / MySQL</h5>
		<p> Running a MySQL server on my own machine. All the PHP I wrote as well </p>
		<h5>Design</h5>
		<p> Used this forum as reference. <a href="http://forums.digitalwarfare247.com/forum/167-black-ops-2/ ">Digital Warfare 24/7</a>
		<br> The only actual thing I took though was the logo, otherwise its all my own HTML/CSS/PHP</p>
		<img src="images/dw247.png" style="box-sizing: border-box; border: 2px solid black; width: 900px;">
		
	</div>
@stop