@extends('layouts.base')

@section('content')
	<div class="container-fluid">
		<h4>Now I am on the Contact Page</h4>
		<br>
		<p>Theres nothing here yet?</p>
	</div>
@stop