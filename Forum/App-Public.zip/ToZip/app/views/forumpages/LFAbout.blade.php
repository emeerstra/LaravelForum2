@extends('layouts.base')

@section('content')
	<div class="container-fluid">
		<div class="row-fluid">
			<h1> On the about page</h1>
			<p>Controller logic maybe?</p>
		</div>
	</div>
@stop