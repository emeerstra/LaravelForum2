@extends('layouts.base')
@section('content')
	<p> On the user login page</p>
	
@stop
	